package day1213;

public class Ex1Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//switch 문
		int n=4;

		switch(n) {
		case 1:
			System.out.println("one");
			break;
		case 2:
			System.out.println("two");
			break;
		case 3:
			System.out.println("three");
			break;
		default:
			System.out.println("other number");
		}
	}

}
